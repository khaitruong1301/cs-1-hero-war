#Kịch bản game
+ Nhân vật hero sẽ di chuyển tìm các thiên thạch hoặc bắn phá thiên thạch để tính điểm
+ Các bước làm game
    + Tạo và blit các surface (text, img, time ) lên màn hình
    + Load các mixer (âm thanh nhạc nền)
    + Xử lý kịch bản (di chuyển nhân vật, bắn đạn, ăn điểm, ....) => Chuyển động, thay đổi(tăng điểm, tăng mạng, giảm điểm, giảm mạng) surface và xử lý va chạm 
    + Phát triển game lặp lại các bước trên
